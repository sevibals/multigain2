= Requirements =

Linux operating system with Docker (Tested with: Docker version 23.0.3).

= Gurobi =

To use the LP solver Gurobi (strongly encouraged!) in the docker, you may acquire a (free for acedemic use) license to the WLS servers in the Gurobi Web License Manager at
https://license.gurobi.com
For further information we refer the user to the documentation:
https://license.gurobi.com/manager/doc/overview
After acquiring the license, download the license file and place it as "gurobi.lic" into the "build" directory.

= Running the Experiments =

*Open a terminal in the directory of this README.

* Execute the command (1.) to build the docker image (requires ~1.5GB memory, ~5 minutes). Alternatively if you want to install Gurobi (strongly encouraged) with MultiGain2 follow the instructions in the "Gurobi" section above and use command (2.) for building the docker image.

1. docker build -t multigain2 build/
2. docker build -t multigain2 build/ --build-arg GUROBI=true

* Run the docker image using the following command:

docker run -v "$(pwd)/results:/home/multigain2/results:rw" \
    -v "$(pwd)/examples:/home/multigain2/examples/host:ro" \
    -w "/home/multigain2" \
    -it multigain2 bash
    
* You have now entered the multigain2 directory inside the container:
    *./examples: Contains the examples from the paper and further
    *./doc: Contains further documentation on how to use multigain2
    *./README.pdf: A rendered version of the contents of the "doc" directory
    (As docker already installed Gurobi and MultiGain2 for you, the corresponding sections in the README.pdf may be skipped.)

* Each "examples" subdirectory contains a bash script to run all examples, which may be executed from any working directory. The results are logged into the ./results directory.

= Experimental results =

All experiments from the corresponding tool paper were performed on a computer with 8 GB of RAM and 4× Intel®CoreTM i5-6200U CPU @ 2.30GHz processor, running Arch Linux, and each run was restricted to a 1 GB of RAM using Gurobi as the LP solver. 
To replicate the results from the paper execute the run.sh scripts provided in the subdirectories "grid" (Table 5.1) and "meanpayoff" (Table 5.2) of the "examples" directory. The results are found in the corresponding "results" subdirectories. For the full results of Table 5.1 of the thesis, the propertyfile "grid.props" in the "examples/grid" subdirectory may be modified by commenting out the prepared queries.
With the specified CPU and Gurobi, both shell script take about 5 minutes each to execute.
Further clarification and replication of the results from my thesis can be found in the README.pdf in the "build" directory. Note that the docker container does not support visualization of the Pareto frontiers. To replicate these results, please install MultiGain2.0 manually as described in the section below.
    
= Custom Models =    
    
To solve custome models and queries, place your model and property files in the "examples" directory before running the docker image. The directory will be mounted inside the docker environment as ./examples/host. You can run your custom examples with the following general command from the root of the multigain2 directory (inside the docker environment):

bin/multigain2 ./examples/host/model_file_name ./examples/host/property_file_name 

Further instructions and options are discussed in the README.pdf. To log the output instead of printing it to the console the user may add "> ./results/host/log_file_name.log" to the end of the command. Further options such as GUROBI or policy export may be found in the README.pdf in the "build" directory.
    
= Installation without Docker =

To manually build MultiGain2.0 without docker, please extract the ZIP-file "multigain2.zip" in the "build" directory and follow the instructions of the README.pdf within. This README.pdf can also be found directly in the "build" directory.
